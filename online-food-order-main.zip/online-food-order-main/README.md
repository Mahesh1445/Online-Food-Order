# online-food-order(CDAC Project.)

Technologies Used: Front-end: JSP
                   Back-end: Spring Boot
                   Database: MySQL

Entity Relation Diagram(ERD): 
![image](https://github.com/vipulmane6498/online-food-order/assets/113690721/c5a18021-ca23-4bb7-9f3e-6439ef7e6368)

                                                            Admin:

      
1. HomePage:
  ![WhatsApp Image 2023-07-08 at 03 57 46](https://github.com/vipulmane6498/online-food-order/assets/113690721/abcc26f5-4790-47e1-957b-76bc4d694aee)


2. Registration Page:
 ![WhatsApp Image 2023-07-08 at 03 57 48](https://github.com/vipulmane6498/online-food-order/assets/113690721/f756b735-9ded-4bfc-9bf4-dcd08d81cb06)


3. Admin Login Page:
  ![WhatsApp Image 2023-07-08 at 03 57 44](https://github.com/vipulmane6498/online-food-order/assets/113690721/e2ea4117-af18-4701-8e47-ae28f54833f0)

   
5. Admin Panel(where admin can do CRUD operations with users, category, food items, orders):
   ![WhatsApp Image 2023-07-08 at 03 57 43](https://github.com/vipulmane6498/online-food-order/assets/113690721/32b05639-29ee-4ca4-b268-42adb6a61844)


6. Admin can add category:
   ![WhatsApp Image 2023-07-08 at 03 57 45](https://github.com/vipulmane6498/online-food-order/assets/113690721/737b20e5-b4cf-4f6d-a899-29ab943df51b)


7. Admin can view added categories:
   ![WhatsApp Image 2023-07-08 at 03 57 49](https://github.com/vipulmane6498/online-food-order/assets/113690721/dddd5343-2a83-4c6a-b3bb-0e854d0e3993)


8. Admin can add food items:
   ![WhatsApp Image 2023-07-08 at 03 57 47](https://github.com/vipulmane6498/online-food-order/assets/113690721/ccf90ad6-3614-49e9-88bd-d104d441f02c)

9. Admin can update or delete food items:
    ![WhatsApp Image 2023-07-08 at 03 57 48](https://github.com/vipulmane6498/online-food-order/assets/113690721/786a7fbb-a921-41be-9696-e59939c412d7)
   

10. Admin can view added food items:
   ![WhatsApp Image 2023-07-08 at 03 57 48](https://github.com/vipulmane6498/online-food-order/assets/113690721/876cc64c-c68b-43e2-bde7-62eecdec3e58)


11. Admin can view all customer placed orders:
    ![WhatsApp Image 2023-07-08 at 03 57 47](https://github.com/vipulmane6498/online-food-order/assets/113690721/5d6fbb9f-714f-4a48-9877-8791c9e7c2c2)


                                                  Customer:


12. Customer Registration:
    
    ![WhatsApp Image 2023-07-08 at 03 57 44](https://github.com/vipulmane6498/online-food-order/assets/113690721/285aaae4-3412-4bde-9b29-6a1ace355341)

14. Customer Login:
    
    ![WhatsApp Image 2023-07-08 at 03 57 49](https://github.com/vipulmane6498/online-food-order/assets/113690721/74d2b54d-5aa0-40c1-9640-0520de4b7ee3)


15. HomePage:
    
    ![WhatsApp Image 2023-07-08 at 03 57 46](https://github.com/vipulmane6498/online-food-order/assets/113690721/7a74ebbe-f11d-4587-9208-e5bc1c9ced33)

    
16. AboutUs Page:
    
    ![WhatsApp Image 2023-07-08 at 03 57 48](https://github.com/vipulmane6498/online-food-order/assets/113690721/eca5b67e-8f09-4ce5-9923-49471f129e92)

17. ContactUs Page:
    
    ![WhatsApp Image 2023-07-08 at 03 57 45](https://github.com/vipulmane6498/online-food-order/assets/113690721/204cfb8e-d2e6-49dd-a0c7-7fd8bddff930)


18. Food items:
    
    ![WhatsApp Image 2023-07-08 at 03 57 46](https://github.com/vipulmane6498/online-food-order/assets/113690721/8fbd4bec-9c49-4e9e-aba0-78ea064abc84)
    ![WhatsApp Image 2023-07-08 at 03 57 45](https://github.com/vipulmane6498/online-food-order/assets/113690721/06ce3775-9d49-4b21-af97-be77fc324344)


18: Add to Cart:
    ![WhatsApp Image 2023-07-08 at 03 57 46](https://github.com/vipulmane6498/online-food-order/assets/113690721/1de065e2-ee88-4509-bb33-328935be8bbc)


19. Payment Page:
    
    ![WhatsApp Image 2023-07-08 at 03 57 44](https://github.com/vipulmane6498/online-food-order/assets/113690721/f34526f7-4ca5-4163-ac46-318a5fa3451f)




   


